Web Application Design and Development (COMP 3421)

MID PROJECT


***Instructions:***
Although I have tried on different devices, in order to show my personal web page clearly, there are some instructions in the following:

0. STUDENT NAME: WONG PAK HO (ID NO: 20020436D）
1. URL:http://tristanwongph.42web.io/
2. Uploading my web files on the public server, there may be some bugs, such as some Chinese characters that should not be disappeared. 
3. The public server provider is https://infinityfree.net/
4. Some of code is developed and powered by :https://getbootstrap.com/docs/5.0/getting-started/browsers-devices/ and the content is provided by myself.
